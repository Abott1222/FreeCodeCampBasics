// Setup all of the objects in the game.
var game = new Game();