# node-express-boilerplate

## To install
```shell
npm install
```

## To run
```
npm start
```

index.html is located in the `public` folder.
